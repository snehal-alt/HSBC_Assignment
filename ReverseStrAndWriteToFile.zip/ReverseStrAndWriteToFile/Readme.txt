//Use Java 17 to run below commands

1) Compile and Run ReverseFileContent class
	javac  ReverseFileContent.java

	java ReverseFileContent

2) Compile and Run ReverseFileContentTest class

	javac -cp junit-4.13.2.jar;. ReverseFileContentTest.java

	java -cp .;junit-4.13.2.jar;hamcrest-core-1.3.jar org.junit.runner.JUnitCore ReverseFileContentTest